const classicBeh = Behavior({
    properties: {
        img: String,
        content: String,
        hidden:Boolean
    },
    attached:function(){

    },
    data:{

    },
    methods:{

    }
})

export {classicBeh}