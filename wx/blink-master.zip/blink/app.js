App({
  onLaunch: function() {}
})

// Promise Async / Await

// wx.cloud({
  
//})

