const config = {
  api_base_url: 'http://bl.7yue.pro/v1/',
  appkey: "请访问www.7yue.pro获取appkey",
}



export {
  config
}